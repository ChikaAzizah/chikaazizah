// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Controlador do Cabe\u00e7alho",signin:"Iniciar sess\u00e3o",signout:"Terminar Sess\u00e3o",about:"Sobre",signInTo:"Iniciar sess\u00e3o em",cantSignOutTip:"Esta fun\u00e7\u00e3o encontra-se indispon\u00edvel em modo de previsualiza\u00e7\u00e3o.",more:"mais",_localized:{}}});